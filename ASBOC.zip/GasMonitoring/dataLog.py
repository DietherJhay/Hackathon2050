import time
import sqlite3
import serial

ser = serial.Serial('/dev/ttyACM0', 9600)

dbname='sensorsData.db'

def getdata():
    data = ser.readline().decode('ascii') # read data then decode to true value

    return data
# log sensor data on database
def logData (data):
	conn=sqlite3.connect(dbname)
	curs=conn.cursor()
	curs.execute("INSERT INTO gas_data values(datetime('now'), (?))", (data,))
	conn.commit()
	conn.close()

while True:
    data = getdata()
    logData (data)
    time.sleep(1)
