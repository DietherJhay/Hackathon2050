import sqlite3 as lite
import sys
con = lite.connect('sensorsData.db')
with con:
    cur = con.cursor()
    cur.execute("DROP TABLE IF EXISTS gas_data")
    cur.execute("CREATE TABLE gas_data(timestamp DATETIME, data)")
