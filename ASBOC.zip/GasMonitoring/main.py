from flask import * # from flask lib import everything    ###to install flask "sudo pip3 install flask"
import serial
import time
import json

ser = serial.Serial('/dev/ttyACM0', 9600) #using " ls /dev/tty* " to find the right ttyACM0, baudrate of 9600

samplingRate = 1

app = Flask(__name__)

@app.route("/")
def index():
   #pass the another and another1 pass to index render_template
   return render_template('index.html')
@app.route("/user")
def user():
   #pass the another and another1 pass to index render_template
   return render_template('user.html')

@app.route('/thing')
def thing():
    def get_thing_values():
        while True:
            while (ser.inWaiting() == 0): # wait here until there is data
              pass # do nothing
            data =ser.readline().decode('ascii')




            # Build up a dict of the current thing state.
            thing_state = {
                'val': data

            }
            # Send the thing state as a JSON object.
            yield('data: {0}\n\n'.format(json.dumps(thing_state)))
            # Wait a second and repeat.
            time.sleep(samplingRate)
    return Response(get_thing_values(), mimetype='text/event-stream')

if __name__ == "__main__":
   app.run(host= '0.0.0.0',debug=True, threaded = True) # thread true two run multiple things run at same time
